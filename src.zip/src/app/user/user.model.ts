export class user{
    id: number=0;
    fullname:string='';
    mobile:string='';
    email:string='';
    password:string='';
}
